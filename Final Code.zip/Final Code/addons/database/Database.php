<?php

namespace addons\database;

use app\common\library\Menu;
use think\Addons;

class Database extends Addons
{

    public function install()
    {
        $menu = [
            [
                'name'    => 'general/database',
                'title'   => 'Database management',
                'icon'    => 'fa fa-database',
                'remark'  => 'You can perform some simple database table optimization or repair online, and view the table structure and data. You can also perform SQL statement operations',
                'sublist' => [
                    ['name' => 'general/database/index', 'title' => 'View'],
                    ['name' => 'general/database/query', 'title' => 'Inquire'],
                ]
            ]
        ];
        Menu::create($menu, 'general');
        return true;
    }

    public function uninstall()
    {

        Menu::delete('general/database');
        return true;
    }

}

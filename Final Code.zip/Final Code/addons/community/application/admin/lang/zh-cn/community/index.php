<?php
return [
    'Id'                => 'ID',
    'Postcode'              => 'Postcode',
    'PostcodeNS'              => 'PostcodeNS',
    'LSOA11'             => 'LSOA11',
    'MSOA11'      => 'MSOA11',
    'WardCodeONSNSPL'           => 'WardCodeONSNSPL',
    'WardNameONSNSPL'              => 'WardNameONSNSPL',
    'ConstituencyCodeONSNSPL'         => 'ConstituencyCodeONSNSPL',
    'ConstituencyNameONSNSPL'            => 'ConstituencyNameONSNSPL',
    'CCG'      => 'CCG',
    'WardCodeCurrent'     => 'WardCodeCurrent',
    'ConstituencyCodeCurrent'        => 'ConstituencyCodeCurrent',
	'Latitude'           => 'Latitude',
    'Longitude'        => 'Longitude'
    
];
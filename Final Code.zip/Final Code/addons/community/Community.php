<?php

namespace addons\community;

use app\common\library\Menu;
use think\Addons;

class Community extends Addons
{

    public function install()
    {
        $menu = [
            [
                'name'    => 'community/index',
                'title'   => 'Community management',
                'remark'  => 'Basic information for managing each cell',
                'icon'    => 'fa fa-list-alt',
                'sublist' => [
                    ['name' => 'community/index/index', 'title' => 'View'],
                    ['name' => 'community/index/detail', 'title' => 'Detail'],
                    ['name' => 'community/index/add', 'title' => 'Add'],
                    ['name' => 'community/index/edit', 'title' => 'Revise'],
                    ['name' => 'community/index/del', 'title' => 'Delete'],
                ],
                'weigh'   => 200
            ]
        ];
        Menu::create($menu);
        return true;
    }

    public function uninstall()
    {
        Menu::delete('community/index');
        return true;
    }

}

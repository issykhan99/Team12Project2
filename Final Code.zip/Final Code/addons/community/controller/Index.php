<?php

namespace addons\community\controller;

use think\addons\Controller;

class Index extends Controller {

    public function index() {
        $this->error("Currently, the plugin does not have a foreground page");
    }

}
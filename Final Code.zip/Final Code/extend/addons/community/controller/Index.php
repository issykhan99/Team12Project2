<?php

namespace addons\community\controller;

use think\addons\Controller;

class Index extends Controller {

    public function index() {
        $this->error("There is currently no foreground page for the plugin");
    }

}
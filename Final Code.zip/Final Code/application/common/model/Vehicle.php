<?php

namespace app\common\model;

use think\Model;

class Vehicle extends Model {

    // 表名,不含前缀
    public $name = 'vehicle';

    // 开启自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';

    public function member(){
        return $this->belongsTo('Member','member_id','id');
    }

}
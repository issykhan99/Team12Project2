<?php

namespace app\common\model;

use think\Model;

class Duty extends Model {
    // 表名,不含前缀
    public $name = 'duty';

    public function community(){
        return $this->belongsTo('Community','community_code','code');
    }
}
<?php

namespace app\common\model;

use think\Model;

class DeviceMaintain extends Model {

    // 表名,不含前缀
    public $name = 'device_maintain';

}
<?php

namespace app\common\controller;

use think\controller\Rest;

class Api extends Rest
{

    public function _initialize()
    {

    }

}

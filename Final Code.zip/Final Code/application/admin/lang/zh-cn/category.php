<?php

return [
    'Id'           => 'ID',
    'Pid'          => 'Parent ID',
    'Type'         => 'Column type',
    'Image'        => 'Image',
    'Keywords'     => 'Keywords',
    'Description'  => 'Description',
    'Diy name'     => 'Custom name',
    'Create time'  => 'Creation time',
    'Update time'  => 'Update time',
    'Weigh'        => 'weight',
    'Status'       => 'Status'
];

<?php

return [
    'Group'             => 'Membership group',
    'Login time'        => 'Last log in',
    'Community'         => 'Membership group',
    'All Community'     => '所有小区'
];

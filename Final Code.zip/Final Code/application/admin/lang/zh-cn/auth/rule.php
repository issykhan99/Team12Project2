<?php

return [
    'Toggle all'                                           => 'Show All',
    'Condition'                                            => 'Rule conditions',
    'Remark'                                               => 'Remark',
    'Icon'                                                 => 'Icon',
    'Alert'                                                => 'Warn',
    'Name'                                                 => 'Rule URL',
    'Controller/Action'                                    => 'Controller name/method name',
    'Menu'                                              => 'Menu',
    'Search icon'                                          => 'Search icon',
    'The non-menu rule must have parent'                   => 'Non-menu rule nodes must have parents',
    'If not necessary, use the command line to build rule' => 'If it is not necessary, please use the command line PHP Think Menu directly to generate it',
];

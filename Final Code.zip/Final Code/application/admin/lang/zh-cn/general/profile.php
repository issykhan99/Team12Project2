<?php

return [
    'Url'                                         => 'Link',
    'Userame'                                     => 'Username',
    'Createtime'                                  => 'Operation time',
    'Admin log'                                   => 'Operational logs',
    'Leave password blank if dont want to change' => 'Please leave the password blank',
];

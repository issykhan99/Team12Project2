<?php

namespace app\api\library;

class ConstStatus {
    const CODE_SUCCESS = '10000';
    const CODE_ERROR = '10001';
}
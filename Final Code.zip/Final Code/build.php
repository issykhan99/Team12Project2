<?php

return [
// Generate the app public file
    '__file__' => ['hello.php', 'test.php'],
    // Automatic generation of the definition demo module (generated according to the actual defined file name)
    'demo' => [
        '__file__'   => ['common.php'],
        '__dir__'    => ['behavior', 'controller', 'model', 'view'],
        'controller' => ['Index', 'Test', 'UserType'],
        'model'      => ['User', 'UserType'],
        'view'       => ['index/index'],
    ],
        // Other more module definitions
];

define(['jquery', 'bootstrap', 'backend', 'table', 'form', 'baidueditor'], function ($, undefined, Backend, Table, Form, UE) {

    var Controller = {
        index: function () {
            // Initialize the table parameter configuration
            Table.api.init({
                extend: {
                    index_url: 'community/index',
                    add_url: 'community/index/add',
                    edit_url: 'community/index/edit',
                    del_url: 'community/index/del',
					 import_url: 'community/index/import',
                    detail_url: 'community/index/detail',
                    table: 'community',
                }
            });

            var table = $("#table");

            // Initializing the table
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                escape: false,
                pk: 'id',
                sortName: 'id',
                pagination: true,
                pageSize: 10,
                commonSearch: false,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'Postcode', title: __('Postcode'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'PostcodeNS', title: __('PostcodeNS'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'LSOA11', title: __('LSOA11'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'MSOA11', title: __('MSOA11'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'WardCodeONSNSPL', title: __('WardCodeONSNSPL'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'WardNameONSNSPL', title: __('WardNameONSNSPL'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'ConstituencyCodeONSNSPL', title: __('ConstituencyCodeONSNSPL'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'ConstituencyNameONSNSPL', title: __('ConstituencyNameONSNSPL'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'CCG', title: __('CCG'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'WardCodeCurrent', title: __('WardCodeCurrent'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'Latitude', title: __('Latitude'), operate: false, formatter: Table.api.formatter.image},
                        {field: 'Longitude', title: __('Longitude'),operate: false, formatter: Table.api.formatter.image},
                        {table:Table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // Bind events to the table
            Table.api.bindevent(table);
        },
        detail: function () {
            var editor = UE.getEditor('container');
            Controller.api.bindevent();
        },
        add: function () {
            var editor = UE.getEditor('container');
            Controller.api.bindevent();
        },
        edit: function () {
            var editor = UE.getEditor('container');
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
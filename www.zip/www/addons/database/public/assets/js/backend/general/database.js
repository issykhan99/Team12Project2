define(['jquery', 'bootstrap', 'backend'], function ($, undefined, Backend) {

    var Controller = {
        index: function () {

            //Disables the shutdown event for Dropdown when the Select element is manipulated
            $("#database").on('click', '.dropdown-menu input, .dropdown-menu label, .dropdown-menu select', function (e) {
                e.stopPropagation();
            });

            //Check for delete or erase operations when submitting
            $("#database").on("submit", "#sqlexecute", function () {
                var v = $("#sqlquery").val().toLowerCase();
                if ((v.indexOf("delete ") >= 0 || v.indexOf("truncate ") >= 0) && !confirm(__('Are you sure you want to delete or turncate?'))) {
                    return false;
                }
            });

            //Event button actions
            $("#database").on("click", "ul#subaction li input", function () {
                $("#topaction").val($(this).attr("rel"));
                return true;
            });

            //When the window changes, the height of the result column is reset
            $(window).on("resize", function () {
                $("#database .well").height($(window).height() - $("#database #sqlexecute").height() - $("#ribbon").outerHeight() - $(".panel-heading").outerHeight() - 130);
            });

            //FIX THE BUG THAT IFRAMES CANNOT BE SCROLLED UNDER IOS
            if (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream) {
                $("#resultparent").css({"-webkit-overflow-scrolling": "touch", "overflow": "auto"});
            }

            $(window).resize();
        }
    };
    return Controller;
});
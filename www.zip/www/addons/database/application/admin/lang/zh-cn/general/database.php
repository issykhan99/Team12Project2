<?php

return [
    'SQL Result'                                                             => 'Query results',
    'Basic query'                                                            => 'Base query',
    'View structure'                                                         => 'Review the table structure',
    'View data'                                                              => 'View table data',
    'Optimize'                                                               => 'Optimize tables',
    'Repair'                                                                 => 'Repair the table',
    'Optimize all'                                                           => 'Optimize all tables',
    'Repair all'                                                             => 'Repair all tables',
    'Table:%s'                                                               => 'Total: %s tables',
    'Record:%s'                                                              => 'Record: %s entry',
    'Data:%s'                                                                => 'Occupancy: %s',
    'Index:%s'                                                               => 'Index: %s',
    'SQL Result:'                                                            => 'Query results:',
    'SQL can not be empty'                                                   => 'Sal statement cannot be empty',
    'Max output:%s'                                                          => 'The maximum return %s bar',
    'Total:%s'                                                               => 'Total %s records!',
    'Row:%s'                                                                 => 'Record: %s',
    'Executes one or multiple queries which are concatenated by a semicolon' => 'Please enter the SQL statement, support batch query, and divide multiple SQL statements with semicolons (;)',
    'Query affected %s rows and took %s seconds'                             => 'Total impact %s records! Time consumed: %s seconds!',
    'Query returned an empty result'                                         => 'The return result is empty!',
    'Query took %s seconds'                                                  => 'It takes %s seconds!',
    'Optimize table %s done'                                                 => 'Optimization table [%s] succeeded',
    'Repair table %s done'                                                   => 'Repair table [%s] succeeded',
    'Optimize table %s fail'                                                 => 'Failed to optimize table [%s]',
    'Repair table %s fail'                                                   => 'Failed to repair table [%s]'
];


<?php


//如果有定义绑定后台模块则禁用路由规则 
if (\think\Route::getBind('module') == 'admin')
    return [];

return [
    //别名配置,别名只能是映射到控制器且访问时必须加上请求的方法
//    '__alias__'   => [
//        'demo' => 'admin/Test',
//    ],
    '__pattern__' => [
        'name' => '\w+',
    ],
    '[hello]'     => [
        ':id'   => ['index/hello', ['method' => 'get'], ['id' => '\d+']],
        ':name' => ['index/hello', ['method' => 'post']],
    ],
//        域名绑定到模块
//        '__domain__'  => [
//            'admin' => 'admin',
//            'api'   => 'api',
//        ],
    // 定义资源路由
    '__rest__' => [
        'article' => 'api/general.article',
        'category' => 'api/general.category',
        'frontnav' => 'api/general.frontNav',
        'slide' => 'api/general.slide',
        'friendlylink' => 'api/general.friendlyLink',
    ]
];

<?php

return [
    'Title' => 'Title',
];

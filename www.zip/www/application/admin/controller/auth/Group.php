<?php

namespace app\admin\controller\auth;

use app\admin\model\AuthGroup;
use app\common\controller\Backend;
use fast\Tree;

class Group extends Backend
{

    protected $model = null;
    //All subgroups of the current Log in administrator
    protected $childrenGroupIds = [];
    //Current group Column table data
    protected $groupdata = [];
    //Method without permission judgment
    protected $noNeedRight = ['roletree'];

    public function _initialize()
    {
        parent::_initialize();
        $this->model = model('AuthGroup');

        $this->childrenGroupIds = $this->auth->getChildrenGroupIds(true);

        $groupName = AuthGroup::where('id', 'in', $this->childrenGroupIds)
                ->column('id,name');
        foreach ($groupName as $k => &$v)
        {
            $v = __($v);
        }
        unset($v);

        $this->groupdata = $groupName;
        $this->assignconfig("admin", ['id' => $this->auth->id, 'group_ids' => $this->auth->getGroupIds()]);

        $this->view->assign('groupdata', $this->groupdata);
    }

    public function index()
    {
        if ($this->request->isAjax())
        {
            $list = [];
            foreach ($this->groupdata as $k => $v)
            {
                $data = $this->model->get($k);
                $data->name = $v;
                $list[] = $data;
            }
            $total = count($list);
            $result = array("total" => $total, "rows" => $list);

            return json($result);
        }
        return $this->view->fetch();
    }

    public function add()
    {
        if ($this->request->isPost())
        {
            $params = $this->request->post("row/a", [], 'strip_tags');
            $params['rules'] = explode(',', $params['rules']);
            if (!in_array($params['pid'], $this->childrenGroupIds))
            {
                $this->error(__('The parent group can not be its own child'));
            }
            $parentmodel = model("AuthGroup")->get($params['pid']);
            if (!$parentmodel)
            {
                $this->error(__('The parent group can not found'));
            }
            // parent level rule node
            $parentrules = explode(',', $parentmodel->rules);
            // the rule node for the current group
            $currentrules = $this->auth->getRuleIds();
            $rules = $params['rules'];
            // If the parent group is not a super administrator, you need to filter the rule node, which cannot exceed the permissions of the parent group
            $rules = in_array('*', $parentrules) ? $rules : array_intersect($parentrules, $rules);
            // If the current group is not a super administrator, you need to filter the rule node, and you cannot exceed the permissions of the current group
            $rules = in_array('*', $currentrules) ? $rules : array_intersect($currentrules, $rules);
            $params['rules'] = implode(',', $rules);
            if ($params)
            {
                $this->model->create($params);
                $this->success();
            }
            $this->error();
        }
        return $this->view->fetch();
    }

    public function edit($ids = NULL)
    {
        $row = $this->model->get(['id' => $ids]);
        if (!$row)
            $this->error(__('No Results were found'));
        if ($this->request->isPost())
        {
            $params = $this->request->post("row/a", [], 'strip_tags');

            if (!in_array($params['pid'], $this->childrenGroupIds))
            {
                $this->error(__('The parent group can not be its own child'));
            }
            $params['rules'] = explode(',', $params['rules']);

            $parentmodel = model("AuthGroup")->get($params['pid']);
            if (!$parentmodel)
            {
                $this->error(__('The parent group can not found'));
            }

            $parentrules = explode(',', $parentmodel->rules);

            $currentrules = $this->auth->getRuleIds();
            $rules = $params['rules'];

            $rules = in_array('*', $parentrules) ? $rules : array_intersect($parentrules, $rules);

            $rules = in_array('*', $currentrules) ? $rules : array_intersect($currentrules, $rules);
            $params['rules'] = implode(',', $rules);
            if ($params)
            {
                $row->save($params);
                $this->success();
            }
            $this->error();
            return;
        }
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }

    public function del($ids = "")
    {
        if ($ids)
        {
            $ids = explode(',', $ids);
            $grouplist = $this->auth->getGroups();
            $group_ids = array_map(function($group) {
                return $group['id'];
            }, $grouplist);
            // Remove the current administrator's group
            $ids = array_diff($ids, $group_ids);

            // Loop to determine whether each group can be deleted
            $grouplist = $this->model->where('id', 'in', $ids)->select();
            $groupaccessmodel = model('AuthGroupAccess');
            foreach ($grouplist as $k => $v)
            {
                // There are administrators under the current group
                $groupone = $groupaccessmodel->get(['group_id' => $v['id']]);
                if ($groupone)
                {
                    $ids = array_diff($ids, [$v['id']]);
                    continue;
                }
                // There are subgroups under the current group
                $groupone = $this->model->get(['pid' => $v['id']]);
                if ($groupone)
                {
                    $ids = array_diff($ids, [$v['id']]);
                    continue;
                }
            }
            if (!$ids)
            {
                $this->error(__('You can not delete group that contain child group and administrators'));
            }
            $count = $this->model->where('id', 'in', $ids)->delete();
            if ($count)
            {
                $this->success();
            }
        }
        $this->error();
    }

    public function multi($ids = "")
    {
        $this->error();
    }

    public function roletree()
    {
        $this->loadlang('auth/group');

        $model = model('AuthGroup');
        $id = $this->request->post("id");
        $pid = $this->request->post("pid");
        $parentgroupmodel = $model->get($pid);
        $currentgroupmodel = NULL;
        if ($id)
        {
            $currentgroupmodel = $model->get($id);
        }
        if (($pid || $parentgroupmodel) && (!$id || $currentgroupmodel))
        {
            $id = $id ? $id : NULL;
            $ruleList = collection(model('AuthRule')->order('weigh', 'desc')->select())->toArray();
            //Read the Column table of all nodes of the parent role
            $parentRuleList = [];
            if (in_array('*', explode(',', $parentgroupmodel->rules)))
            {
                $parentRuleList = $ruleList;
            }
            else
            {
                $parent_rule_ids = explode(',', $parentgroupmodel->rules);
                foreach ($ruleList as $k => $v)
                {
                    if (in_array($v['id'], $parent_rule_ids))
                    {
                        $parentRuleList[] = $v;
                    }
                }
            }

            //All current normal rule Column tables
            Tree::instance()->init($ruleList);

            //Read the set of rule IDs under the current role
            $admin_rule_ids = $this->auth->getRuleIds();
            //Is it a super administrator
            $superadmin = $this->auth->isSuperAdmin();
            //The set of currently owned rule IDs
            $current_rule_ids = $id ? explode(',', $currentgroupmodel->rules) : [];

            if (!$id || !in_array($pid, Tree::instance()->getChildrenIds($id, TRUE)))
            {
                $ruleList = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0), 'name');
                $hasChildrens = [];
                foreach ($ruleList as $k => $v)
                {
                    if ($v['haschild'])
                        $hasChildrens[] = $v['id'];
                }
                $nodelist = [];
                foreach ($parentRuleList as $k => $v)
                {
                    if (!$superadmin && !in_array($v['id'], $admin_rule_ids))
                        continue;
                    $state = array('selected' => in_array($v['id'], $current_rule_ids) && !in_array($v['id'], $hasChildrens));
                    $nodelist[] = array('id' => $v['id'], 'parent' => $v['pid'] ? $v['pid'] : '#', 'text' => __($v['title']), 'type' => 'menu', 'state' => $state);
                }
                $this->success('', null, $nodelist);
            }
            else
            {
                $this->error(__('Can not change the parent to child'));
            }
        }
        else
        {
            $this->error(__('Group not found'));
        }
    }

}

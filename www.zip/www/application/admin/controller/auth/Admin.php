<?php

namespace app\admin\controller\auth;

use app\admin\model\AuthGroup;
use app\admin\model\AuthGroupAccess;
use app\common\controller\Backend;
use fast\Random;
use fast\Tree;
use think\Session;


class Admin extends Backend
{

    protected $model = null;
    protected $childrenGroupIds = [];
    protected $childrenAdminIds = [];
    protected $communityModel = null;
    //Fields to match when searching
    protected $searchfields = 'username,nickname,email';

    public function _initialize()
    {
        parent::_initialize();
        $this->model = model('Admin');
        $this->getAdminIds();
        $this->childrenGroupIds = $this->auth->getChildrenGroupIds(true);
        $groupName = AuthGroup::where('id', 'in', $this->childrenGroupIds)
                ->column('id,name');

        $this->view->assign('groupdata', $groupName);
        $this->assignconfig("admin", ['id' => $this->auth->id]);
        $this->communityModel = model('Community');
        $this->view->assign('community',$this->communityModel->where(array('code'=>array('in',parent::getCommunityIdByAuth())))->field('code,name')->select());
    }

    public function index()
    {
        if ($this->request->isAjax())
        {

            //$childrenGroupIds = $this->auth->getChildrenAdminIds(true);
            $childrenGroupIds = $this->auth->getChildrenGroupIds(true);
            $groupName = AuthGroup::where('id', 'in', $childrenGroupIds)
                    ->column('id,name');
            $authGroupList = AuthGroupAccess::where('group_id', 'in', $childrenGroupIds)
                    ->field('uid,group_id')
                    ->select();

            $adminGroupName = [];
            foreach ($authGroupList as $k => $v)
            {
                if (isset($groupName[$v['group_id']]))
                $adminGroupName[$v['uid']][$v['group_id']] = $groupName[$v['group_id']];
            }
            $this->buildCommonSearch();
            list($where, $sort, $order, $offset, $limit) = $this->buildparams($this->searchfields);
            $total = $this->model
                    ->where($where)
                    ->where('id', 'in', $this->childrenAdminIds)
                    ->order($sort, $order)
                    ->count();

            $list = $this->model
                    ->where($where)
                    ->where('id', 'in', $this->childrenAdminIds)
                    ->field(['password', 'salt', 'token'], true)
                    ->order($sort, $order)
                    ->limit($offset, $limit)
                    ->select();
            foreach ($list as $k => &$v)
            {
                $groups = isset($adminGroupName[$v['id']]) ? $adminGroupName[$v['id']] : [];
                $v['groups'] = implode(',', array_keys($groups));
                $v['groups_text'] = implode(',', array_values($groups));
            }
            unset($v);
            $result = array("total" => $total, "rows" => $list);

            return json($result);
        }
        return $this->view->fetch();
    }

    public function add()
    {
        if ($this->request->isPost())
        {
            $params = $this->request->post("row/a");
            if ($params)
            {
                $params['salt'] = Random::alnum();
                $params['password'] = md5(md5($params['password']) . $params['salt']);
                $params['avatar'] = '/assets/img/avatar.png'; //Set the default avatar for new administrators.
                if ($this->model->checkExists('username',$params['username']) !== false) {
                    $this->error('the user already exists');
                }

                $admin = $this->model->create($params);
                $this->addCommunity($admin->id);
                $group = $this->request->post("group/a");

                //Filter disallowed groups to avoid overreach
                $group = array_intersect($this->childrenGroupIds, $group);
                $dataset = [];
                foreach ($group as $value)
                {
                    $dataset[] = ['uid' => $admin->id, 'group_id' => $value];
                }
                model('AuthGroupAccess')->saveAll($dataset);
                $this->success();
            }
            $this->error();
        }
        return $this->view->fetch();
    }

    public function edit($ids = NULL)
    {
        $row = $this->model->get(['id' => $ids]);
        if (!$row)
            $this->error(__('No Results were found'));
        if ($this->request->isPost())
        {
            $params = $this->request->post("row/a");
            if ($params)
            {
                if ($params['password'])
                {
                    $params['salt'] = Random::alnum();
                    $params['password'] = md5(md5($params['password']) . $params['salt']);
                }
                else
                {
                    unset($params['password'], $params['salt']);
                }

                if ($this->model->checkExists('username',$params['username'],$ids) !== false) {
                    $this->error('the user already exists');
                }

                $row->save($params);
                $this->updateCommunity($row->id);

                model('AuthGroupAccess')->where('uid', $row->id)->delete();

                $group = $this->request->post("group/a");

                // Filter disallowed groups to avoid overreach
                $group = array_intersect($this->childrenGroupIds, $group);

                $dataset = [];
                foreach ($group as $value)
                {
                    $dataset[] = ['uid' => $row->id, 'group_id' => $value];
                }
                model('AuthGroupAccess')->saveAll($dataset);
                $this->success();
            }
            $this->error();
        }
        $grouplist = $this->auth->getGroups($row['id']);
        $groupids = [];
        foreach ($grouplist as $k => $v)
        {
            $groupids[] = $v['id'];
        }
        $this->view->assign("row", $row);
        $this->view->assign("groupids", $groupids);
        $this->view->assign('selectedCommunity',model('CommunityAdmin')->getCodeByAdminId($ids));
        return $this->view->fetch();
    }

    public function del($ids = "")
    {
        if ($ids)
        {
            // Avoid unauthorized deletion of administrators
            $childrenGroupIds = $this->childrenGroupIds;
            $adminList = $this->model->where('id', 'in', $ids)->where('id', 'in', function($query) use($childrenGroupIds) {
                        $query->name('auth_group_access')->where('group_id', 'in', $childrenGroupIds)->field('uid');
                    })->select();
            if ($adminList)
            {
                $deleteIds = [];
                foreach ($adminList as $k => $v)
                {
                    $deleteIds[] = $v->id;
                }
                $deleteIds = array_diff($deleteIds, [$this->auth->id]);
                if ($deleteIds)
                {
                    $this->model->destroy($deleteIds);
                    model('AuthGroupAccess')->where('uid', 'in', $deleteIds)->delete();
                    $this->success();
                }
            }
        }
        $this->error();
    }

    public function multi($ids = "")
    {
        $this->error();
    }

    protected function buildCommonSearch() {
        $where = array();
        $searchs = $this->request->request('query/a');
        if ($searchs['community_code']) {
            $adminIds = model('CommunityAdmin')->getAdmins($searchs['community_code']);
            $this->childrenAdminIds = array_intersect($adminIds,$this->childrenAdminIds);
        }
    }

    protected function getAdminIds() {
        $admin = Session::get('admin');
        if($admin) {
            $userInfo = json_decode($admin,true);
            $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
            if ($this->auth->checkIsSuperAdmin($userInfo['id']) === false) {
                $adminIds = model('CommunityAdmin')->getAdmins(parent::getCommunityIdByAuth());
                $this->childrenAdminIds = array_intersect($adminIds,$this->childrenAdminIds);
            }
        }
    }

    protected function addCommunity($id) {
        model('CommunityAdmin')->addCommunity($this->request->post('community_code/a'),$id);
    }

    protected function updateCommunity($id) {
        model('CommunityAdmin')->updateCommunity($this->request->post('community_code/a'),$id);
    }

}

<?php

return array (
  'autoload' => false,
  'hooks' => 
  array (
  ),
);
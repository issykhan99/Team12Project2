<?php
/**
 * Created by PhpStorm.
 * FileName: Article.php
 * User: Administrator
 * Date: 2017/10/20
 * Time: 13:51
 */

namespace app\common\model;


use think\Model;

class DeviceMaintain extends Model {

    // 表名,不含前缀
    public $name = 'device_maintain';

}
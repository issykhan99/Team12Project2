<?php

namespace think;

// ThinkPHP boot file
// Load the base file
require __DIR__ . '/base.php';
// execute application
App::run()->send();

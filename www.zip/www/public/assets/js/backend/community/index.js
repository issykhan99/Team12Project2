define(['jquery', 'bootstrap', 'backend', 'table', 'form', 'baidueditor'], function ($, undefined, Backend, Table, Form, UE) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'community/index',
                    add_url: 'community/index/add',
                    edit_url: 'community/index/edit',
                    del_url: 'community/index/del',
					import_url: 'community/index/import',
                    detail_url: 'community/index/detail',
                    table: 'community',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                escape: false,
                pk: 'id',
                sortName: 'id',
                pagination: true,
                pageSize: 10,
                commonSearch: false,
                columns: [
                    [
                        {checkbox: true},
                           {field: 'id', title: __('Id')},
                        {field: 'Postcode', title: __('Postcode'),  operate: false},
                        {field: 'PostcodeNS', title: __('PostcodeNS'), operate: false},
                        {field: 'LSOA11', title: __('LSOA11'), operate: false},
                        {field: 'MSOA11', title: __('MSOA11'), operate: false},
                        {field: 'WardCodeONSNSPL', title: __('WardCodeONSNSPL'), operate: false},
                        {field: 'WardNameONSNSPL', title: __('WardNameONSNSPL'), operate: false},
                        {field: 'ConstituencyCodeONSNSPL', title: __('ConstituencyCodeONSNSPL'), operate: false},
                        {field: 'ConstituencyNameONSNSPL', title: __('ConstituencyNameONSNSPL'), operate: false},
                        {field: 'CCG', title: __('CCG'), operate: false},
                        {field: 'WardCodeCurrent', title: __('WardCodeCurrent'), operate: false},
                        {field: 'Latitude', title: __('Latitude'),operate: false},
                        {field: 'Longitude', title: __('Longitude'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        detail: function () {
            var editor = UE.getEditor('container');
            Controller.api.bindevent();
        },
        add: function () {
            var editor = UE.getEditor('container');
            Controller.api.bindevent();
        },
        edit: function () {
            var editor = UE.getEditor('container');
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
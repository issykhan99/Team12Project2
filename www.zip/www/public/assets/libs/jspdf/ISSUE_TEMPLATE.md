Thank you for submitting an issue to jsPDF. Please read carefully.

**Are you using the latest version of jsPDF?**

**Have you tried using jspdf.debug.js?**

**Steps to reproduce**

Ideally a link too. Try fork this http://jsbin.com/rilace/edit?html,js,output

**What I saw**

**What I expected**

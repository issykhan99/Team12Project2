# SelectPage
A jQuery plugin include autocomplete,pagination,tags,keybord navigation functions

plugin preview  
![SelectPage](https://terryz.github.io/image/SelectPage.png)


## Key Features

<ul>
	<li>jQuery plugin</li>
	<li>A item select plugin for bootstrap2(unsupport bootstrap3)</li>
	<li>brower supper IE8+,chrome,firefox</li>
</ul>

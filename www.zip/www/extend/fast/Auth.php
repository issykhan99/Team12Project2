<?php

// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2011 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: luofei614 <weibo.com/luofei614>
// +----------------------------------------------------------------------
// | 修改者: anuo (本权限类在原3.2.3的基础上修改过来的)
// +----------------------------------------------------------------------

namespace fast;

use think\Db;
use think\Config;
use think\Session;
use think\Request;
use think\Loader;

class Auth
{
    protected static $instance;
    protected $rules = [];

    protected $request;

    protected $config = [
        'auth_on'           => 1, // Permission switch
        'auth_type'         => 1, // Authentication method, 1 is real-time authentication; 2 is Log in authentication.
        'auth_group'        => 'auth_group', // User group data table name
        'auth_group_access' => 'auth_group_access', // User-user group relationship table
        'auth_rule'         => 'auth_rule', // Permission rules table
        'auth_user'         => 'user', // User information table
    ];

    public function __construct()
    {
        if ($auth = Config::get('auth'))
        {
            $this->config = array_merge($this->config, $auth);
        }

        $this->request = Request::instance();
    }

    public static function instance($options = [])
    {
        if (is_null(self::$instance))
        {
            self::$instance = new static($options);
        }

        return self::$instance;
    }

    public function check($name, $uid, $relation = 'or', $mode = 'url')
    {
        if (!$this->config['auth_on'])
        {
            return true;
        }

        $rulelist = $this->getRuleList($uid);
        if (in_array('*', $rulelist))
            return true;

        if (is_string($name))
        {
            $name = strtolower($name);
            if (strpos($name, ',') !== false)
            {
                $name = explode(',', $name);
            }
            else
            {
                $name = [$name];
            }
        }
        $list = []; //Save the name of the rule that passed the validation
        if ('url' == $mode)
        {
            $REQUEST = unserialize(strtolower(serialize($this->request->param())));
        }
        foreach ($rulelist as $rule)
        {
            $query = preg_replace('/^.+\?/U', '', $rule);
            if ('url' == $mode && $query != $rule)
            {
                parse_str($query, $param); //解析规则中的param
                $intersect = array_intersect_assoc($REQUEST, $param);
                $rule = preg_replace('/\?.*$/U', '', $rule);
                if (in_array($rule, $name) && $intersect == $param)
                {
                    //如果节点相符且url参数满足
                    $list[] = $rule;
                }
            }
            else
            {
                if (in_array($rule, $name))
                {
                    $list[] = $rule;
                }
            }
        }
        if ('or' == $relation && !empty($list))
        {
            return true;
        }
        $diff = array_diff($name, $list);
        if ('and' == $relation && empty($diff))
        {
            return true;
        }

        return false;
    }


    public function getGroups($uid)
    {
        static $groups = [];
        if (isset($groups[$uid]))
        {
            return $groups[$uid];
        }
        // Convert the table name
        $auth_group_access = Loader::parseName($this->config['auth_group_access'], 1);
        $auth_group = Loader::parseName($this->config['auth_group'], 1);
        // Execute the query
        $user_groups = Db::view($auth_group_access, 'uid,group_id')
                ->view($auth_group, 'id,pid,name,rules', "{$auth_group_access}.group_id={$auth_group}.id", 'LEFT')
                ->where("{$auth_group_access}.uid='{$uid}' and {$auth_group}.status='normal'")
                ->select();
        $groups[$uid] = $user_groups ?: [];

        return $groups[$uid];
    }

    public function getRuleList($uid)
    {
        static $_rulelist = []; //Save the permissions that the user authenticates in the Column table
        if (isset($_rulelist[$uid]))
        {
            return $_rulelist[$uid];
        }
        if (2 == $this->config['auth_type'] && Session::has('_rule_list_' . $uid))
        {
            return Session::get('_rule_list_' . $uid);
        }

        // Read the user rule node
        $ids = $this->getRuleIds($uid);
        if (empty($ids))
        {
            $_rulelist[$uid] = [];
            return [];
        }

        // Filter criteria
        $where = [
            'status' => 'normal'
        ];
        if (!in_array('*', $ids))
        {
            $where['id'] = ['in', $ids];
        }
        //Read all permission rules for user groups
        $this->rules = Db::name($this->config['auth_rule'])->where($where)->field('id,pid,condition,icon,name,title,ismenu')->select();
        
        //Loop rules, judge the result.
        $rulelist = []; //
        if (in_array('*', $ids))
        {
            $rulelist[] = "*";
        }
        foreach ($this->rules as $rule)
        {
            //Super administrators do not need to verify condition
            if (!empty($rule['condition']) && !in_array('*', $ids))
            {
                //Verify according to the condition
                $user = $this->getUserInfo($uid); //获取用户信息,一维数组
                $command = preg_replace('/\{(\w*?)\}/', '$user[\'\\1\']', $rule['condition']);
                @(eval('$condition=(' . $command . ');'));
                if ($condition)
                {
                    $rulelist[$rule['id']] = strtolower($rule['name']);
                }
            }
            else
            {
                //Record as long as it exists
                $rulelist[$rule['id']] = strtolower($rule['name']);
            }
        }
        $_rulelist[$uid] = $rulelist;
        //Log in validation requires saving the Rule Column table
        if (2 == $this->config['auth_type'])
        {
            //The results of the Rule Column table are saved to the session
            Session::set('_rule_list_' . $uid, $rulelist);
        }
        return array_unique($rulelist);
    }

    public function getRuleIds($uid)
    {
        //Read the user groups to which the user belongs
        $groups = $this->getGroups($uid);
        $ids = []; //Saves all permission rule IDs set by the user group to which the user belongs
        foreach ($groups as $g)
        {
            $ids = array_merge($ids, explode(',', trim($g['rules'], ',')));
        }
        $ids = array_unique($ids);
        return $ids;
    }


    protected function getUserInfo($uid)
    {
        static $user_info = [];

        $user = Db::name($this->config['auth_user']);
        // Gets the user table primary key
        $_pk = is_string($user->getPk()) ? $user->getPk() : 'uid';
        if (!isset($user_info[$uid]))
        {
            $user_info[$uid] = $user->where($_pk, $uid)->find();
        }

        return $user_info[$uid];
    }

}
